// peer.c
// Single-peer: runs a receiver thread (always listens) and accepts "send <ip> <filepath> <window>" commands on stdin.
// Compile: gcc peer.c -o peer -lpthread
// Usage: ./peer [listen_port]
// Default listen port = 5001

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h>

#define DEFAULT_PORT 5001
#define PACKET_DATA 1000
#define HEADER_SIZE (sizeof(int32_t)*3) // seq, size, eof
#define MAX_WINDOW 64
#define TIMEOUT_MS 1000

// Packet header: seq (int32), size (int32), eof (int32), then data[]
// Special control packet: seq = -1, data = filename (null-terminated)
typedef struct {
    int32_t seq;
    int32_t size;
    int32_t eof;
    char data[PACKET_DATA];
} Packet;

typedef struct {
    int32_t ack_seq;
} AckPacket;

int listen_port = DEFAULT_PORT;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;

long long now_ms() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000;
}

void safe_printf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    pthread_mutex_lock(&print_mutex);
    vprintf(fmt, ap);
    printf("\n");
    fflush(stdout);
    pthread_mutex_unlock(&print_mutex);
    va_end(ap);
}

void *receiver_thread_func(void *arg) {
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len = sizeof(cliaddr);
    Packet pkt;
    char current_filename[512] = {0};
    FILE *fp = NULL;
    int32_t expected_seq = 0;
    ssize_t n;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("receiver socket");
        pthread_exit(NULL);
    }
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(listen_port);

    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("bind");
        close(sockfd);
        pthread_exit(NULL);
    }

    safe_printf("[Receiver] Listening on port %d", listen_port);

    while (1) {
        n = recvfrom(sockfd, &pkt, sizeof(pkt), 0, (struct sockaddr *)&cliaddr, &len);
        if (n < 0) {
            safe_printf("[Receiver] recvfrom error: %s", strerror(errno));
            continue;
        }

        int32_t seq = ntohl(pkt.seq);
        int32_t size = ntohl(pkt.size);
        int32_t eof = ntohl(pkt.eof);

        // Control packet: seq == -1 => filename
        if (seq == -1) {
            // filename is in pkt.data
            memset(current_filename, 0, sizeof(current_filename));
            snprintf(current_filename, sizeof(current_filename)-1, "%s", pkt.data);
            // open file for writing (overwrite)
            if (fp) { fclose(fp); fp = NULL; }
            fp = fopen(current_filename, "wb");
            if (!fp) {
                safe_printf("[Receiver] Failed to open file '%s' for writing: %s", current_filename, strerror(errno));
            } else {
                safe_printf("[Receiver] Incoming file: %s (opened for writing)", current_filename);
                expected_seq = 0;
            }
            // send ACK -1? We'll ack nothing; keep protocol: send ack_seq = expected_seq - 1
            AckPacket ack;
            ack.ack_seq = htonl(expected_seq - 1);
            sendto(sockfd, &ack, sizeof(ack), 0, (struct sockaddr *)&cliaddr, len);
            continue;
        }

        safe_printf("[Receiver] pkt seq=%d size=%d eof=%d expected=%d", seq, size, eof, expected_seq);

        if (!fp) {
            safe_printf("[Receiver] No file opened yet - ignoring packet");
        } else {
            if (seq == expected_seq) {
                if (size > 0) {
                    fwrite(pkt.data, 1, size, fp);
                    fflush(fp);
                }
                expected_seq++;
            } else {
                safe_printf("[Receiver] out-of-order pkt %d (expected %d) - ignoring", seq, expected_seq);
            }

            // send ACK for last in-order packet (expected_seq - 1)
            AckPacket ack;
            ack.ack_seq = htonl(expected_seq - 1);
            ssize_t sent = sendto(sockfd, &ack, sizeof(ack), 0, (struct sockaddr *)&cliaddr, len);
            if (sent < 0) {
                safe_printf("[Receiver] ACK send failed: %s", strerror(errno));
            } else {
                safe_printf("[Receiver] Sent ACK %d", expected_seq - 1);
            }

            if (eof && seq == expected_seq - 1) {
                safe_printf("[Receiver] Final packet received. File '%s' complete.", current_filename);
                if (fp) { fclose(fp); fp = NULL; }
                // reset filename
                current_filename[0] = '\0';
                expected_seq = 0;
            }
        }
    }

    close(sockfd);
    pthread_exit(NULL);
}

// Send file to target_ip using Go-Back-N
// Returns 0 on success, non-zero on error
int send_file(const char *target_ip, const char *filepath, int WINDOW) {
    if (WINDOW <= 0) WINDOW = 4;
    if (WINDOW > MAX_WINDOW) WINDOW = MAX_WINDOW;

    // open file
    FILE *fp = fopen(filepath, "rb");
    if (!fp) {
        safe_printf("[Sender] Failed to open '%s': %s", filepath, strerror(errno));
        return 1;
    }

    // prepare UDP socket
    int sockfd;
    struct sockaddr_in servaddr;
    socklen_t addrlen = sizeof(servaddr);

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        safe_printf("[Sender] socket error");
        fclose(fp);
        return 1;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(listen_port); // receiver listens on same port
    if (inet_pton(AF_INET, target_ip, &servaddr.sin_addr) <= 0) {
        safe_printf("[Sender] invalid target IP: %s", target_ip);
        fclose(fp);
        close(sockfd);
        return 1;
    }

    // Build list of packets in memory (simple approach)
    Packet *packets = NULL;
    size_t total_pkts = 0;
    while (!feof(fp)) {
        Packet p;
        memset(&p, 0, sizeof(p));
        p.seq = htonl((int32_t)total_pkts);
        size_t nread = fread(p.data, 1, PACKET_DATA, fp);
        p.size = htonl((int32_t)nread);
        p.eof = htonl(nread < PACKET_DATA ? 1 : 0);
        packets = realloc(packets, sizeof(Packet) * (total_pkts + 1));
        if (!packets) {
            safe_printf("[Sender] memory alloc failed");
            fclose(fp);
            close(sockfd);
            return 1;
        }
        packets[total_pkts] = p;
        total_pkts++;
        if (nread < PACKET_DATA) break;
    }
    fclose(fp);

    safe_printf("[Sender] File '%s' split into %zu packets. Window=%d", filepath, total_pkts, WINDOW);

    // First send control packet with filename (seq = -1)
    {
        Packet ctrl;
        memset(&ctrl, 0, sizeof(ctrl));
        ctrl.seq = htonl(-1);
        const char *fname = strrchr(filepath, '/');
        if (fname) fname++; else fname = filepath;
        strncpy(ctrl.data, fname, PACKET_DATA-1);
        ctrl.size = htonl((int32_t)strlen(ctrl.data));
        ctrl.eof = htonl(0);
        sendto(sockfd, &ctrl, sizeof(Packet), 0, (struct sockaddr *)&servaddr, addrlen);
        safe_printf("[Sender] Sent control packet (filename=%s)", ctrl.data);
    }

    int base = 0;
    int nextseq = 0;
    long long send_time[MAX_WINDOW];
    memset(send_time, 0, sizeof(send_time));
    AckPacket ack;
    fd_set readfds;
    struct timeval tv;
    int finished = 0;

    while (!finished) {
        // send as many as window allows
        while (nextseq < (int)total_pkts && nextseq < base + WINDOW) {
            Packet *p_net = &packets[nextseq];
            ssize_t s = sendto(sockfd, p_net, sizeof(Packet), 0, (struct sockaddr *)&servaddr, addrlen);
            if (s < 0) {
                safe_printf("[Sender] sendto error: %s", strerror(errno));
            } else {
                int seq_host = ntohl(p_net->seq);
                int size_host = ntohl(p_net->size);
                int eof_host = ntohl(p_net->eof);
                safe_printf("[Sender] Sent pkt seq=%d size=%d eof=%d", seq_host, size_host, eof_host);
            }
            send_time[nextseq % WINDOW] = now_ms();
            nextseq++;
        }

        // wait for ACK or timeout
        FD_ZERO(&readfds);
        FD_SET(sockfd, &readfds);
        tv.tv_sec = 0;
        tv.tv_usec = 100 * 1000; // poll 100ms for responsiveness
        int rv = select(sockfd + 1, &readfds, NULL, NULL, &tv);
        if (rv > 0 && FD_ISSET(sockfd, &readfds)) {
            ssize_t n = recvfrom(sockfd, &ack, sizeof(ack), 0, NULL, NULL);
            if (n > 0) {
                int ack_seq = ntohl(ack.ack_seq);
                safe_printf("[Sender] ACK received: %d", ack_seq);
                if (ack_seq >= base) {
                    base = ack_seq + 1;
                }
                if (base >= (int)total_pkts) {
                    finished = 1;
                    break;
                }
            }
        }

        // check timeout for base packet
        if (base < nextseq) {
            long long elapsed = now_ms() - send_time[base % WINDOW];
            if (elapsed >= TIMEOUT_MS) {
                // timeout -> retransmit window from base to nextseq-1
                safe_printf("[Sender] Timeout; retransmitting from %d to %d", base, nextseq - 1);
                for (int i = base; i < nextseq; ++i) {
                    Packet *p_net = &packets[i];
                    ssize_t s = sendto(sockfd, p_net, sizeof(Packet), 0, (struct sockaddr *)&servaddr, addrlen);
                    if (s < 0) {
                        safe_printf("[Sender] resend error: %s", strerror(errno));
                    } else {
                        safe_printf("[Sender] Re-Sent pkt %d", ntohl(p_net->seq));
                    }
                    send_time[i % WINDOW] = now_ms();
                }
            }
        }
    }

    safe_printf("[Sender] All packets sent and ACKed. Sending EOF notification done.");

    free(packets);
    close(sockfd);
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc >= 2) {
        listen_port = atoi(argv[1]);
        if (listen_port <= 0) listen_port = DEFAULT_PORT;
    }

    pthread_t receiver_thread;
    if (pthread_create(&receiver_thread, NULL, receiver_thread_func, NULL) != 0) {
        perror("pthread_create");
        return 1;
    }

    // Main thread: read commands from stdin
    // Commands:
    //   send <target_ip> <filepath> [window]
    //   quit
    // Example:
    //  send 192.168.1.50 /home/user/file.bin 4

    safe_printf("[Peer] Ready. Enter commands: send <ip> <filepath> [window]  OR quit");
    char line[1024];
    while (fgets(line, sizeof(line), stdin)) {
        // remove trailing newline
        char *nl = strchr(line, '\n'); if (nl) *nl = '\0';
        if (strlen(line) == 0) continue;
        if (strncmp(line, "quit", 4) == 0) {
            safe_printf("[Peer] Quitting.");
            break;
        }
        if (strncmp(line, "send ", 5) == 0) {
            // parse
            char target[64] = {0};
            char path[512] = {0};
            int window = 4;
            int parsed = sscanf(line + 5, "%63s %511s %d", target, path, &window);
            if (parsed < 2) {
                safe_printf("[Peer] Invalid send command. Usage: send <ip> <filepath> [window]");
                continue;
            }
            safe_printf("[Peer] Initiating send to %s of file %s with window %d", target, path, window);
            int res = send_file(target, path, window);
            if (res == 0) safe_printf("[Peer] Send completed successfully.");
            else safe_printf("[Peer] Send failed with code %d", res);
            continue;
        }
        safe_printf("[Peer] Unknown command: %s", line);
    }

    // exit: detach receiver thread (we'll just exit process)
    pthread_cancel(receiver_thread);
    pthread_join(receiver_thread, NULL);
    return 0;
}
