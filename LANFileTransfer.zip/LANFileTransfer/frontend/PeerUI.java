// FileTransferUI.java
// Compile: javac FileTransferUI.java
// Run: java FileTransferUI
// Ensure the compiled 'peer' binary is in same folder and executable (chmod +x peer)

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Files;

public class PeerUI extends JFrame {
    private JTextArea logArea;
    private JButton startPeerBtn;
    private JButton chooseFileBtn;
    private JButton sendBtn;
    private JTextField targetIpField;
    private JTextField windowField;
    private JLabel selectedFileLabel;
    private Process peerProcess;
    private File selectedFile;
    private BufferedWriter peerWriter;

    public PeerUI() {
        super("LAN File Transfer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLayout(new BorderLayout());

        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane sp = new JScrollPane(logArea);
        add(sp, BorderLayout.CENTER);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        startPeerBtn = new JButton("Start Peer");
        top.add(startPeerBtn);
        top.add(new JLabel("Target IP:"));
        targetIpField = new JTextField(12);
        top.add(targetIpField);
        top.add(new JLabel("Window:"));
        windowField = new JTextField("4", 3);
        top.add(windowField);
        chooseFileBtn = new JButton("Choose File");
        top.add(chooseFileBtn);
        selectedFileLabel = new JLabel("No file chosen");
        top.add(selectedFileLabel);
        sendBtn = new JButton("Send File");
        top.add(sendBtn);

        add(top, BorderLayout.NORTH);

        startPeerBtn.addActionListener(e -> startPeer());
        chooseFileBtn.addActionListener(e -> chooseFile());
        sendBtn.addActionListener(e -> sendFile());

        appendLog("UI ready. Click 'Start Peer' to launch the backend peer process.");
    }

    private void appendLog(String s) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(s + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    private void startPeer() {
        if (peerProcess != null && peerProcess.isAlive()) {
            appendLog("Peer already running.");
            return;
        }
        try {
            if (!Files.exists(new File("./peer").toPath())) {
                appendLog("peer binary not found in current directory.");
                return;
            }
            ProcessBuilder pb = new ProcessBuilder("./peer");
            pb.redirectErrorStream(true);
            peerProcess = pb.start();
            appendLog("Started peer process.");
            peerWriter = new BufferedWriter(new OutputStreamWriter(peerProcess.getOutputStream()));

            // thread to read peer stdout
            new Thread(() -> {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(peerProcess.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        appendLog("[Peer] " + line);
                    }
                } catch (IOException ex) {
                    appendLog("Error reading peer output: " + ex.getMessage());
                }
            }).start();

        } catch (IOException ex) {
            appendLog("Failed to start peer: " + ex.getMessage());
        }
    }

    private void chooseFile() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = fc.getSelectedFile();
            selectedFileLabel.setText(selectedFile.getName());
            appendLog("Selected file: " + selectedFile.getAbsolutePath());
        }
    }

    private void sendFile() {
        if (peerProcess == null || !peerProcess.isAlive()) {
            appendLog("Peer is not running. Click 'Start Peer' first.");
            return;
        }
        if (selectedFile == null) {
            appendLog("Choose a file first.");
            return;
        }
        String targetIp = targetIpField.getText().trim();
        if (targetIp.isEmpty()) {
            appendLog("Enter target IP.");
            return;
        }
        String windowStr = windowField.getText().trim();
        int window = 4;
        try { window = Integer.parseInt(windowStr); } catch (Exception ex) { window = 4; }

        // send command to peer's stdin: send <ip> <filepath> <window>
        String cmd = String.format("send %s %s %d\n", targetIp, selectedFile.getAbsolutePath(), window);
        try {
            peerWriter.write(cmd);
            peerWriter.flush();
            appendLog("Sent command to peer: " + cmd.trim());
        } catch (IOException ex) {
            appendLog("Failed to write to peer stdin: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PeerUI ui = new PeerUI();
            ui.setVisible(true);
        });
    }
}
